<?php

// migration file: 2023_xx_xx_create_arsip_infos_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateArsipInfosTable extends Migration
{
    public function up()
    {
        Schema::create('arsip_infos', function (Blueprint $table) {
            $table->id();
            $table->text('arsip_info')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('arsip_infos');
    }
}

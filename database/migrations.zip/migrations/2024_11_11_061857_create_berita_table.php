<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBeritaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('beritas', function (Blueprint $table) { // Ensure table name is consistent here
            $table->id();
            $table->string('title');
            $table->string('cover')->nullable(); // For storing cover image path
            $table->text('content'); // Main content of the article
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('beritas'); // Match the table name here to avoid issues during rollback
    }
}

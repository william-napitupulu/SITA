<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSaranaPrasaranaTable extends Migration
{
    public function up()
    {
        Schema::create('sarana_prasarana', function (Blueprint $table) {
            $table->id();
            $table->string('cover')->nullable(); // Path to the cover image
            $table->string('nama'); // Name of the facility
            $table->text('deskripsi')->nullable(); // Description
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('sarana_prasarana');
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBerandaInformationTable extends Migration
{
    public function up()
    {
        Schema::create('beranda_information', function (Blueprint $table) {
            $table->id();
            $table->string('kontak_phone')->nullable();
            $table->string('kontak_email')->nullable();
            $table->string('nama_lokasi')->nullable();
            $table->string('alamat_lokasi')->nullable();
            $table->text('peta_lokasi')->nullable(); // Changed to text for longer URLs
            $table->text('sosial_media_instagram')->nullable(); // Changed to text
            $table->text('sosial_media_youtube')->nullable(); // Changed to text
            $table->text('sosial_media_tiktok')->nullable(); // Changed to text
            $table->text('sosial_media_facebook')->nullable(); // Changed to text
            $table->text('sosial_media_twitter')->nullable(); // Changed to text
            $table->text('highlight')->nullable();
            $table->text('sub_highlight')->nullable();
            $table->string('cover')->nullable();
            $table->string('judul_video')->nullable();
            $table->text('link_video')->nullable(); // Changed to text for longer URLs
            $table->integer('jumlah_peserta_didik')->default(1);
            $table->integer('jumlah_guru')->default(1);
            $table->integer('jumlah_kelas')->default(1);
            $table->string('photo_kepala_sekolah')->nullable();
            $table->string('nama_kepala_sekolah')->nullable();
            $table->text('sambutan_kepala_sekolah')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('beranda_information');
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePrestasiTable extends Migration
{
    public function up()
    {
        Schema::create('prestasi', function (Blueprint $table) {
            $table->id();
            $table->string('cover')->nullable();
            $table->string('judul');
            $table->year('tahun_perolehan');
            $table->text('deskripsi')->nullable();
            $table->timestamps();
        });
    }
    public function down()
    {
        Schema::dropIfExists('prestasi');
    }
}
